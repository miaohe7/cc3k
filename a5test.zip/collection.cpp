//
//  collection.cpp
//  cc3kcode
//
//  Created by Brandon Weng on 2016-11-26.
//  Copyright © 2016 Brandon Weng. All rights reserved.
//

#include "collection.hpp"
#include "stats.hpp"
#include "treasure.hpp"
#include "potion.hpp"

// Collection -----------------
Collection::Collection(){}

void Collection::set_potion(Potion *p){
    pot = p;
}

void Collection::usePotion(Stats &s,int bonus){
    pot->usePotion(s,bonus);
}

void Collection::set_treasure(Treasure *t){
    this->t = t;
}

void Collection::useTreasure(Stats &s){
    t->pickedUpBy(s);
}
