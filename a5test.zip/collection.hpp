//
//  collection.hpp
//  cc3kcode
//
//  Created by Brandon Weng on 2016-11-26.
//  Copyright © 2016 Brandon Weng. All rights reserved.
//

#ifndef collection_hpp
#define collection_hpp
class Potion;
class Treasure;
class Stats;

class Collection{
    Potion *pot;
    Treasure *t;
public:
    Collection();
    void set_potion(Potion *);
    void usePotion(Stats &,int);
    
    void set_treasure(Treasure *);
    void useTreasure(Stats &);
};


#endif /* collection_hpp */
