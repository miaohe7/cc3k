//
//  Coordinates.h
//  cc3k
//
//  Created by miao he on 27/11/2016.
//  Copyright © 2016 miao he. All rights reserved.
//

#ifndef Coordinates_hpp
#define Coordinates_hpp

struct Coordinates{
    int x,y;
};

#include <stdio.h>

#endif /* Coordinates_hpp */
