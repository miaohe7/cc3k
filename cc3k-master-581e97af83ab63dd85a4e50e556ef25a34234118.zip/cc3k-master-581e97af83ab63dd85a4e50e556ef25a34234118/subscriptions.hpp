#ifndef _SUBSCRIPTIONS_H_
#define _SUBSCRIPTIONS_H_
enum class SubscriptionType {All};
#endif
